library(experimentr)

args <- Experiment.start()

sqrts = sapply(seq(from = 1, to = 2000), sqrt)

out <- data.frame(X = seq(from=1, to = 2000), "sqrt(X)" = sqrts)

write.table(out, file = args$outfiles, row.names = F, quote = F, sep = "\t")

Experiment.stop(args)

